export type StudentStatus =
    | "Active"
    | "Inactive"
    | "TC"
    | "Completed";

export interface Student {

    id:string;

    admissionNo:string;

    institute:"school" | "degree" | "training";

    firstName:string;

    lastName:string;

    gender:"Male" | "Female" | "Other";

    course:string;

    section?:string;

    rollNo:string;

    fatherName:string;

    mobile:string;

    email?:string;

    status:StudentStatus;

}