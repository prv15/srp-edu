import { students } from "../data/students";
import type { Student } from "../types/student";
import type { InstituteType } from "../../../contexts/InstituteContext";

export function getStudents(
    institute: InstituteType
): Student[] {

    return students.filter(

        student => student.institute === institute

    );

}

export function getStudentById(
    id:string
){

    return students.find(

        student => student.id===id

    );

}