export default function OverviewTab(){

    return(

        <>

            <h1>Student Overview</h1>

            <p>

                Complete profile and academic summary.

            </p>

        </>

    )

}