export default function OverviewTab() {
    return (
        <div>
            <h2>Fee</h2>
            <p>Fee content will come here.</p>
        </div>
    );
}