export default function OverviewTab() {
    return (
        <div>
            <h2>Parent</h2>
            <p>Parent content will come here.</p>
        </div>
    );
}