export default function OverviewTab() {
    return (
        <div>
            <h2>Academic</h2>
            <p>Academic content will come here.</p>
        </div>
    );
}