export default function OverviewTab() {
    return (
        <div>
            <h2>Attendance</h2>
            <p>Attendance content will come here.</p>
        </div>
    );
}