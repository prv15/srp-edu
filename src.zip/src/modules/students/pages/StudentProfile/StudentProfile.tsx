import { ArrowLeft } from "lucide-react";
import { useState } from "react";

import OverviewTab from "./tabs/OverviewTab";
import AcademicTab from "./tabs/AcademicTab";
import ParentTab from "./tabs/ParentTab";
import AttendanceTab from "./tabs/AttendanceTab";
import FeeTab from "./tabs/FeeTab";
import DocumentTab from "./tabs/DocumentTab";
import TransportTab from "./tabs/TransportTab";
import LibraryTab from "./tabs/LibraryTab";
import MedicalTab from "./tabs/MedicalTab";
import ExaminationTab from "./tabs/ExaminationTab";

import styles from "./StudentProfile.module.css";

const tabs = [
    "Overview",
    "Academic",
    "Parents",
    "Attendance",
    "Fees",
    "Documents",
    "Transport",
    "Library",
    "Medical",
    "Examination"
];

export default function StudentProfile() {

    const [activeTab, setActiveTab] = useState("Overview");

    const renderContent = () => {

        switch (activeTab) {

            case "Overview":
                return <OverviewTab />;

            case "Academic":
                return <AcademicTab />;

            case "Parents":
                return <ParentTab />;

            case "Attendance":
                return <AttendanceTab />;

            case "Fees":
                return <FeeTab />;

            case "Documents":
                return <DocumentTab />;

            case "Transport":
                return <TransportTab />;

            case "Library":
                return <LibraryTab />;

            case "Medical":
                return <MedicalTab />;

            case "Examination":
                return <ExaminationTab />;

            default:
                return <OverviewTab />;

        }

    };

    return (

        <div className={styles.page}>

            <button className={styles.backButton}>

                <ArrowLeft size={18} />

                Back to Students

            </button>

            <div className={styles.layout}>

                {/* Left Sidebar */}

                <aside className={styles.sidebar}>

                    <div className={styles.profileCard}>

                        <div className={styles.avatar}>

                            RK

                        </div>

                        <h2>

                            Rahul Kumar

                        </h2>

                        <p>

                            Class VIII-A

                        </p>

                        <span className={styles.badge}>

                            Active Student

                        </span>

                    </div>

                    <nav className={styles.navigation}>

                        {tabs.map(tab => (

                            <button

                                key={tab}

                                onClick={() => setActiveTab(tab)}

                                className={
                                    activeTab === tab
                                        ? styles.active
                                        : ""
                                }

                            >

                                {tab}

                            </button>

                        ))}

                    </nav>

                </aside>

                {/* Right */}

                <section className={styles.content}>

                    {renderContent()}

                </section>

            </div>

        </div>

    );

}