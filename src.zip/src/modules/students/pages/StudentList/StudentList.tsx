import type { Student } from "../../types/student";
import type { DataColumn } from "../../../../components/layout/DataTable";
import { Plus, Download } from "lucide-react";

import PageHeader from "../../../../components/layout/PageHeader";
import PageContent from "../../../../components/layout/PageContent";
import StatsGrid from "../../../../components/layout/StatsGrid";
import StatsCard from "../../../../components/layout/StatsCard";
import ActionBar from "../../../../components/layout/ActionBar";
import DataTable from "../../../../components/layout/DataTable";

import SearchField from "../../../../components/forms/SearchField";
import SelectField from "../../../../components/forms/SelectField";

import Button from "../../../../components/ui/Button";

import Badge from "../../../../components/ui/Badge";

import Avatar from "../../../../components/ui/Avatar";

export default function StudentList(){

    const columns: DataColumn<Student>[] = [

    {

        key: "student",

        title: "Student",

        render: (row: Student) => (

            <div
                style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                }}
            >

                <Avatar
                    name={`${row.firstName} ${row.lastName}`}
                />

                <div>

                    <strong>

                        {row.firstName} {row.lastName}

                    </strong>

                    <div
                        style={{
                            fontSize: 12,
                            color: "#64748b",
                        }}
                    >

                        {row.admissionNo}

                    </div>

                </div>

            </div>

        ),

    },

    {

        key: "course",

        title: "Class",

    },

    {

        key: "fatherName",

        title: "Father",

    },

    {

        key: "mobile",

        title: "Mobile",

    },

    {

        key: "status",

        title: "Status",

        render: (row: Student) =>

            row.status === "Active" ? (

                <Badge variant="success">

                    Active

                </Badge>

            ) : (

                <Badge variant="danger">

                    {row.status}

                </Badge>

            ),

    },

];

   const data: Student[] = [
    {
        id: "1",
        admissionNo: "ADM0001",
        institute: "school",
        firstName: "Prakash",
        lastName: "Raj",
        gender: "Male",
        course: "X",
        section: "A",
        rollNo: "12",
        fatherName: "Raj Kumar",
        mobile: "9876543210",
        email: "prakash@test.com",
        status: "Active",
    },
    {
        id: "2",
        admissionNo: "ADM0002",
        institute: "school",
        firstName: "Amit",
        lastName: "Kumar",
        gender: "Male",
        course: "IX",
        section: "B",
        rollNo: "15",
        fatherName: "Mahesh Kumar",
        mobile: "9988776655",
        email: "amit@test.com",
        status: "Inactive",
    },
];

    return(

        <>

            <PageHeader

    title="Students"

    description="Manage all enrolled students"

/>

            <PageContent>

                <StatsGrid>

                    <StatsCard

                        title="Students"

                        value={2436}

                    />

                    <StatsCard

                        title="Boys"

                        value={1324}

                    />

                    <StatsCard

                        title="Girls"

                        value={1112}

                    />

                    <StatsCard

                        title="Today's Admission"

                        value={18}

                    />

                </StatsGrid>

                <ActionBar

                    left={

                        <>

                            <SearchField/>

                            <SelectField

                                label="Class"

                                options={[]}

                            />

                            <SelectField

                                label="Section"

                                options={[]}

                            />

                        </>

                    }

                    right={

                        <>

                            <Button
                                variant="secondary"
                                icon={<Download size={18}/>}
                            >

                                Export

                            </Button>

                            <Button
                                icon={<Plus size={18}/>}
                            >

                                Add Student

                            </Button>

                        </>

                    }

                />

                <DataTable

                    columns={columns}

                    data={data}

                />

            </PageContent>

        </>

    );

}